<?php $__env->startSection('content'); ?>

<div id="maincarousel" class="carousel slide" data-ride="carousel" style="width: 100%; margin-top: 3%;">
  <!-- Indicators -->
  	<ol class="carousel-indicators">
    	<li data-target="#maincarousel" data-slide-to="0" class="active"></li>
    	<li data-target="#maincarousel" data-slide-to="1"></li>
    	<li data-target="#maincarousel" data-slide-to="2"></li>
    	<li data-target="#maincarousel" data-slide-to="3"></li>
  	</ol>

  	<!-- Wrapper for slides -->
  	<div class="carousel-inner" role="listbox">
      <?php
        $num = 0;
      ?>
      <?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php 
        $num = $num + 1;
      ?>
      <?php if($num == 1): ?>
    	<div class="carousel-item active">
      		<img class="d-block w-100" src="<?php echo e(asset('uploads/images/slide/')); ?>/<?php echo e($slide->file); ?>">
    	</div>
      <?php else: ?>
      <div class="carousel-item">
          <img class="d-block w-100" src="<?php echo e(asset('uploads/images/slide/')); ?>/<?php echo e($slide->file); ?>">
      </div>
      <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<!-- 		<div class="carousel-item">
      		<img class="d-block w-100" src="<?php echo e(asset('images/mainimages/main2.jpg')); ?>" alt="Chicago">
    	</div>

    	<div class="carousel-item">
      		<img class="d-block w-100" src="<?php echo e(asset('images/mainimages/main3.jpg')); ?>" alt="New York">
    	</div>

    	<div class="carousel-item">
      		<img class="d-block w-100" src="<?php echo e(asset('images/mainimages/main4.jpg')); ?>" alt="New York">
    	</div> -->
  	</div>

  	<!-- Left and right controls -->
  	<a class="carousel-control-prev" href="#maincarousel" data-slide="prev">
    	<span class="carousel-control-prev-icon"></span>
    	<span class="sr-only">Previous</span>
  	</a>
  	<a class="carousel-control-next" href="#maincarousel" data-slide="next">
    	<span class="carousel-control-next-icon"></span>
    	<span class="sr-only">Next</span>
  	</a>
</div>

<div class="container main-block">

   <h2>Featured Products</h2></a>
   <div class="row style_featured">
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
      <div class="col-md-4" >
         <div class="item-container" style="width: 80%; text-align: center;">
            <img src="/uploads/images/products/<?php echo e($product->id); ?>/<?php echo e($product->list_img); ?>" style="width: 80%;" />
            <h4 style="margin-top: 5%;"><?php echo e($product->name); ?></h4>

            <p>
               <span class="fa fa-bank "></span>
               <?php echo e($product->model); ?>

            </p>

            <a href="<?php echo e(route('product.detail', [$product->id])); ?>" class="btn btn-success" title="More">View details »</a>
          </div>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

   </div>
   <div class="row"  style="border-bottom: 1px dashed #dddddd;">
     <h6 class="col-md-2 offset-10"><a href="<?php echo e(route('products')); ?>">View more products</a></h6>
   </div>
</div>
<div class="main-block-back">
   <div class="container main-block">
      <a href="<?php echo e(route('news')); ?>" style="color: #000;"><h2>Our News</h2></a>
      <div class="row">
        <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php

            $str_first = explode('src="/', $new->article);
            if(count($str_first) > 1)
             $src = (explode('"', $str_first[1])[0]);
            else
              $src = '';
        ?>
         <div class="col-sm-4">
            <div class="box">
              <a href="<?php echo e(route('news.detail', [$new->id])); ?>" class="row" style="color: #000000; font-size: 18px">
               <img src="<?php echo $src; ?>">
               <div class="details">
                  <h4><?php echo e($new->created_at); ?></h4>
                  <h3><?php echo e($new->topic); ?></h3>
               </div>
             </a>
            </div>
         </div>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         
         
      </div>
   </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\FreelancerTasks\local.linkbasic.com\resources\views/pages/home.blade.php ENDPATH**/ ?>