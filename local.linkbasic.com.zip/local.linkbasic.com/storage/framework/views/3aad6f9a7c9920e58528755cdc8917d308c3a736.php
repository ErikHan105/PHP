<?php $__env->startSection('content'); ?>
<div class="card-body">

   <div class="col-12 tm-block-col">
      <div class="tm-bg-primary-dark tm-block tm-block-taller tm-block-scroll">
         <div class="row">
            <h2 class="col-sm-8 tm-block-title">Products List</h2>
            <div class="col-sm-4" style="text-align: right;"><?php echo e($products->links()); ?></div>
         </div>
         <table class="table">
             <thead>
                 <tr>
                     <th scope="col">NO</th>
                     <th scope="col">Name</th>
                     <th scope="col">Model</th>
                     <th scope="col">Category</th>
                     <th scope="col">Latest Update</th>
                     <th scope="col">Edit</th>
                     <th scope="col">Delete</th>
                     
                 </tr>
             </thead>
             <tbody>
               <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <tr>
                     <th scope="row"><?php echo e($product->id); ?></th>
                     <td><?php echo e($product->name); ?></td>
                     <td><?php echo e($product->model); ?></td>
                     <td><?php echo e($product->getCategory($product->category)->name); ?></td>
                     <td><?php echo e($product->updated_at); ?></td>
                     <td><button class="btn btn-primary edit_product"><a href="<?php echo e(route('admin.add', [$product->id])); ?>" style="color:#ffffff;">Edit</a></button></td>
                     <td><button class="btn btn-danger delete_product" data-product-id="<?php echo e($product->id); ?>" data-toggle="modal" data-target="#delete">Delete</button></td>
                 </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </tbody>
         </table>
     </div>
   </div>
   <div class="modal" id="delete" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true" style="margin-left: 50%; max-height: 280px;">

       <div class="modal-content">
             <div class="modal-header">
           <button type="button" class="close" data-dismiss="modal" aria-hidden="true"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></button>
           <h4 class="modal-title custom_align" id="Heading">Delete this entry</h4>
         </div>
             <div class="modal-body">
          
          <div class="alert alert-danger"><span class="glyphicon glyphicon-warning-sign"></span> Are you sure you want to delete this Record?</div>
          
         </div>
           <div class="modal-footer ">
           <button type="button" class="btn btn-success" id="delete"><a href="" style="color: #000000;"><span class="glyphicon glyphicon-ok-sign"></span>&nbsp;Yes</a></button>

           <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span>&nbsp;No</button>
         </div>
           </div>
       <!-- /.modal-content --> 

      </div>
</div>




<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('ckeditor/samples/css/samples.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('js/jquery.form.js')); ?>"></script>
<script src="<?php echo e(asset('ckeditor/ckeditor.js')); ?>"></script>
<script src="<?php echo e(asset('ckeditor/samples/js/sample.js')); ?>"></script>
<script src="<?php echo e(asset('js/admin.js')); ?>"></script>
<script type="text/javascript">

     
</script>

<?php $__env->stopSection(); ?>



 	


<?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\FreelancerTasks\local.linkbasic.com\resources\views/admin/productlist.blade.php ENDPATH**/ ?>