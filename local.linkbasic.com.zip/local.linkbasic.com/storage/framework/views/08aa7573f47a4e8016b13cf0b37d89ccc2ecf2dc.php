<!DOCTYPE html>
<!DOCTYPE html>
<html>
<head>
	<title>Linkbasic admin panel</title>
   <link rel="shortcut icon" type="image/png" href="<?php echo e(asset('images/logo_picture.png')); ?>">
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/admin.css')); ?>" rel="stylesheet">


    <script src="<?php echo e(asset('ckeditor/ckeditor.js')); ?>"></script>
   <script src="<?php echo e(asset('ckeditor/samples/js/sample.js')); ?>"></script>
   <link rel="stylesheet" href="<?php echo e(asset('ckeditor/samples/css/samples.css')); ?>">


</head>
<body>
   <div id="editor">      
   </div>
<script>
   initSample();
</script>

 	<script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>
   <script src="<?php echo e(asset('js/app.js')); ?>"></script>
   <script src="<?php echo e(asset('js/admin.js')); ?>"></script>
</body>
</html>

<?php /**PATH E:\FreelancerTasks\local.linkbasic.com\resources\views/admin/management.blade.php ENDPATH**/ ?>