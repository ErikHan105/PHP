<?php

/* Update v1.64 */
include "config.php";

$SQL = "CREATE TABLE IF NOT EXISTS `pas_firewall` (
  `id` int(16) NOT NULL AUTO_INCREMENT,
  `ip` text NOT NULL,
  `type` text NOT NULL,
  `pays` text NOT NULL,
  PRIMARY KEY (`id`)
)";
$pdo->query($SQL);

echo "*** Mise à jour de la base de données pour PAS Script v1.66.4 ***<br>";
echo "*** Mise à jour terminer ***<br>";
echo '<a href="'.$url_script.'/admin/home.php">Revenir à l\'administration</a>';
?>