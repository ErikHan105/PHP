<?php $__env->startSection('content'); ?>

<div class="back-image">
	<img src="<?php echo e(asset('images/bg_news.jpg')); ?>" width="100%">
</div>
<div class="container">
	
	<div class="row content">
		<div class="col-sm-3">
			<div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">

				<a class="nav-link disabled" id="v-pills-product-tab" data-toggle="pill" href="#v-pills-product" role="tab" aria-controls="v-pills-product" aria-selected="false">
					<h5>Company News</h5>
				</a>
				
		   	</div>
		   	<div class="row menu-picture">
				<a href="<?php echo e(route('custom')); ?>" class="side-menu"><img src="<?php echo e(asset('images/pdf_download.jpg')); ?>" width="100%"></a>
			</div>
			<div class="row menu-picture">
				<a href="<?php echo e(route('products')); ?>" class="side-menu"><img src="<?php echo e(asset('images/products_.jpg')); ?>" width="100%"></a>
			</div>
			<div class="row menu-picture">
				<a href="<?php echo e(route('contact')); ?>" class="side-menu"><img src="<?php echo e(asset('images/side-contact.jpg')); ?>" width="100%"></a>
			</div>
		</div>
		<div class="col-sm-8" style="text-align: center;">
			<h2>&nbsp;&nbsp;&nbsp;<?php echo e($news->topic); ?></h2>	
			<?php echo $news->article; ?>

		</div>

	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('css/details.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\FreelancerTasks\local.linkbasic.com\resources\views/pages/news_detail.blade.php ENDPATH**/ ?>