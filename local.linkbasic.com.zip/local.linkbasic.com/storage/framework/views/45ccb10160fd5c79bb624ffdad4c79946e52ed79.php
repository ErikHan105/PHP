<?php $__env->startSection('content'); ?>

<div class="back-image">
	<img src="<?php echo e(asset('images/bg_news.jpg')); ?>" width="100%">
</div>
<div class="container">
	
	<div class="row content">
		<div class="col-sm-3">
			<div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">

				<a class="nav-link disabled" id="v-pills-product-tab" data-toggle="pill" href="#v-pills-product" role="tab" aria-controls="v-pills-product" aria-selected="false">
					<h5>Products</h5>
				</a>

				<ul class="list-unstyled" style="margin-top:1%">
					<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($category->parent_id == 0): ?>
					<li class="category" data-category-id="<?php echo e($category->id); ?>" id="product_category_<?php echo e($category->id); ?>"><?php echo e($category->name); ?></li>
<!-- 						<ul class="list-unstyled subcategory">
						<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>						
							<?php if($subcategory->parent_id == $category->id): ?>
							<li data-category-id="<?php echo e($subcategory->id); ?>"><?php echo e($subcategory->name); ?></li>
							<?php endif; ?>						
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</ul> -->
					<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
		   	</div>
		   	<div class="row menu-picture">
				<a href="<?php echo e(route('custom')); ?>" class="side-menu"><img src="<?php echo e(asset('images/pdf_download.jpg')); ?>" width="100%"></a>
			</div>
			<div class="row menu-picture">
				<a href="<?php echo e(route('products')); ?>" class="side-menu"><img src="<?php echo e(asset('images/products_.jpg')); ?>" width="100%"></a>
			</div>
			<div class="row menu-picture">
				<a href="<?php echo e(route('contact')); ?>" class="side-menu"><img src="<?php echo e(asset('images/side-contact.jpg')); ?>" width="100%"></a>
			</div>

		</div>

		<div class="col-sm-8" id="view_products">
			<img src="<?php echo e(asset('images/products.jpg')); ?>" width="100%" style="margin-bottom: 20px;">
			<div class="row">
				<div class="col-sm-7">
					<h2>&nbsp;&nbsp;&nbsp;Products</h2>
				</div>
				<div class="col-sm-5 text-right">
					
				</div>
			</div>
			<div class="row">
				<?php if(isset($category_products)): ?>

				<?php $__currentLoopData = $category_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		        <!-- <div class="col-md-6 col-lg-4 g-mb-30" style="margin-bottom: 3%; margin-top: 2%;">
		          <article class="u-shadow-v18 g-bg-white text-center rounded g-px-20 g-py-40 g-mb-5" style="border: 1px solid #dddddd; min-height: 100%; padding: 5%;">
		            <a href="" class="image_menu" data-category-id="<?php echo e($category_product->id); ?>">
		            	<img class="d-inline-block img-fluid mb-4" src="/uploads/images/categories/<?php echo e($category_product->getCategory($category_product->parent_id)->name); ?>/<?php echo e($category_product->image); ?>"> -->
			            <!-- <h4 class="h5 g-color-black g-font-weight-600 g-mb-10"><?php echo e($category_product->name); ?></h4> -->
			            <!-- <p>Finding your perfect product</p>
			            <span class="d-block g-color-primary g-font-size-16">$50.00</span> -->
			        <!-- </a>
		          </article>
		        </div> -->
		        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		        <!-- <div class="row text-center" style="width:100%; margin-left: 3%;">
			        <?php echo e($category_products->links()); ?>

			    </div> -->
		        <?php endif; ?>

		        <!-- <?php if(isset($products)): ?> -->

				<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		        <div class="col-md-6 col-lg-4 g-mb-30" style="margin-bottom: 3%; margin-top: 2%;">
		          <article class="u-shadow-v18 g-bg-white text-center rounded g-px-20 g-py-40 g-mb-5" style="border: 1px solid #dddddd; min-height: 100%; padding: 5%;">
		            <!-- <a href="<?php echo e(route('product.detail', [$product->id])); ?>" class="product_detail" data-product-id="<?php echo e($product->id); ?>"> -->
		            	<img class="d-inline-block img-fluid mb-4" src="/uploads/images/products/<?php echo e($product->id); ?>/<?php echo e($product->list_img); ?>">
			            <h4 class="h5 g-color-black g-font-weight-600 g-mb-10"><?php echo e($product->name); ?></h4>
			            <h5><a href="<?php echo e(route('product.detail', [$product->id])); ?>" style="color: #3250a2;">View Details</a></h5>
			            <!-- <p>Finding your perfect product</p>
			            <span class="d-block g-color-primary g-font-size-16">$50.00</span> -->
			        <!-- </a> -->
		          </article>
		        </div>
		        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		        <div class="row text-center" style="width:100%; margin-left: 3%;">
			        <?php echo e($products->links()); ?>

			    </div>
		        <!-- <?php endif; ?> -->

		    </div>
		</div>

	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('css/details.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('css/products.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\FreelancerTasks\local.linkbasic.com\resources\views/pages/products.blade.php ENDPATH**/ ?>