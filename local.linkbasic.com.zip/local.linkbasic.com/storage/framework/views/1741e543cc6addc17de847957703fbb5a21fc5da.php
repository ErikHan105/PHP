<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>
    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/index.css')); ?>" rel="stylesheet">
    <link rel='stylesheet' id='compiled.css-css'  href='https://mdbootstrap.com/wp-content/themes/mdbootstrap4/css/compiled-4.8.8.min.css?ver=4.8.8' type='text/css' media='all' />
    <?php echo $__env->yieldContent('css'); ?>
</head>
<body>
	<header id="header">    
	    <div class="container">
	        <div class="row menubar">
	        	<div class="col-sm-2">
	        		<img src="<?php echo e(asset('images/logo.png')); ?>">
	        	</div>     	
	        </div>
	        <nav class="navbar navbar-expand-lg navbar-light blue-grey lighten-5 mb-4">

	      	<!-- Navbar brand -->
	      		<a class="navbar-brand" href="#"></a>

	      		<!-- Collapse button -->
	      		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
	        	aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>

	      	<!-- Collapsible content -->
	      		<div class="collapse navbar-collapse" id="navbarSupportedContent">

			        <ul class="navbar-nav mr-auto">
			          	<li class="nav-item">
			          	  	<a class="nav-link" href="#">Home</a>
			          	</li>
			          	<li class="nav-item">
			            	<a class="nav-link" href="#">About us</a>
			          	</li>
			          	<li class="nav-item">
			            	<a class="nav-link" href="#">Products</a>
			          	</li>
			          	<li class="nav-item">
			            	<a class="nav-link" href="#">News</a>
			          	</li>
			          	<li class="nav-item">
			            	<a class="nav-link" href="#">Support</a>
			          	</li>
			          	<li class="nav-item">
			            	<a class="nav-link" href="#">Customer Service</a>
			          	</li>
			          	<li class="nav-item">
			            	<a class="nav-link" href="#">Contact us</a>
			          	</li>
			        </ul>
			        <form class="form-inline">
			  			<input class="form-control" type="text" placeholder="Search" aria-label="Search">
					</form>      
	  			</div>
	      	<!-- Collapsible content -->

	    	</nav>
	    </div>
	</header>
    <div class="carousel slide" id="MagicCarousel" data-ride="carousel" style="">
    	<ol class="carousel-indicators">
    		<li data-target="#MagicCarousel" date-slide-to="0"></li>
    		<li data-target="#MagicCarousel" date-slide-to="1"></li>
    		<li data-target="#MagicCarousel" date-slide-to="2" class="active"></li>
    		<li data-target="#MagicCarousel" date-slide-to="3"></li>
    		<li data-target="#MagicCarousel" date-slide-to="4"></li>
    	</ol>
    	<div class="carousel-inner" role="listbox">
    		<div class="carousel-item">
    			<img class="d-block w-100" src="<?php echo e(asset('images/download.jpg')); ?>" alt="First Slide">
    			<div class="carousel-caption">
    				<h3>Cinderella</h3>
    				<p>(first slide)</p>
    			</div>
    		</div>
    		<div class="carousel-item">
    			<img class="d-block w-100" src="<?php echo e(asset('images/download(1).jpg')); ?>" alt="Second Slide">
    			<div class="carousel-caption">
    				<h3>Cinderella</h3>
    				<p>(second slide)</p>
    			</div>
    		</div>
    		<div class="carousel-item active">
    			<img class="d-block w-100" src="<?php echo e(asset('images/download(2).jpg')); ?>" alt="Third Slide">
    			<div class="carousel-caption">
    				<h3>Cinderella</h3>
    				<p>(third slide)</p>
    			</div>
    		</div>
    		<div class="carousel-item">
    			<img class="d-block w-100" src="<?php echo e(asset('images/download(3).jpg')); ?>" alt="Fourth Slide">
    			<div class="carousel-caption">
    				<h3>Cinderella</h3>
    				<p>(Fourth slide)</p>
    			</div>
    		</div>
    		<div class="carousel-item">
    			<img class="d-block w-100" src="<?php echo e(asset('images/images.png')); ?>" alt="Fifth Slide">
    			<div class="carousel-caption">
    				<h3>Cinderella</h3>
    				<p>(Fifth slide)</p>
    			</div>
    		</div>
    		<a class="carousel-control-prev" href="#MagicCarousel" role="button" data-slide="prev">
    			<span class="carousel-control-prev-icon"></span>
    			<span class="sr-only">Previous</span>
    		</a>
    		<a class="carousel-control-next" href="#MagicCarousel" role="button" data-slide="next">
    			<span class="carousel-control-next-icon"></span>
    			<span class="sr-only">Next</span>
    		</a>
    	</div>
    	
    </div>

    <div id="app">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    <footer id="footer"><!--Footer-->
        
    </footer><!--/Footer-->
    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
</body>
</html>
<?php /**PATH E:\FreelancerTasks\local.linkbasic.com\resources\views/pages/layout.blade.php ENDPATH**/ ?>