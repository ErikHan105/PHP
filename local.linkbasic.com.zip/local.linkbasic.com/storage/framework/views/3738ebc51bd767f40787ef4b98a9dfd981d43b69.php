<?php $__env->startSection('content'); ?>

<div class="back-image">
	<img src="<?php echo e(asset('images/bg_company.jpg')); ?>" width="100%">
</div>
<div class="container">
	<div class="row content">
		<div class="col-3">
			<div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">

				<a class="nav-link disabled" id="v-pills-product-tab" data-toggle="pill" href="#v-pills-product" role="tab" aria-controls="v-pills-product" aria-selected="false">
					<h5>Download Zone</h5>
				</a>
				<a class="nav-link active" id="v-pills-who-tab" data-toggle="pill" href="#v-pills-who" role="tab" aria-controls="v-pills-news" aria-selected="false">
					<h5>Application Scheme</h5>
				</a>
				<a class="nav-link" id="v-pills-profession-tab" data-toggle="pill" href="#v-pills-profession" role="tab" aria-controls="v-pills-news" aria-selected="false">
					<h5>Products Catalog</h5>
				</a>
				<a class="nav-link" id="v-pills-service-tab" data-toggle="pill" href="#v-pills-service" role="tab" aria-controls="v-pills-news" aria-selected="false">
					<h5>Product coding principle</h5>
				</a>
		   	</div>

			<div class="row menu-picture">
				<a href="<?php echo e(route('products')); ?>" class="side-menu"><img src="<?php echo e(asset('images/products_.jpg')); ?>" width="100%"></a>
			</div>
			<div class="row menu-picture">
				<a href="<?php echo e(route('contact')); ?>" class="side-menu"><img src="<?php echo e(asset('images/side-contact.jpg')); ?>" width="100%"></a>
			</div>
		</div>
		<div class="col-8">
			<div class="tab-content" id="v-pills-tabContent">	      		
	      		<div class="tab-pane fade active show" id="v-pills-who" role="tabpanel" aria-labelledby="v-pills-who-tab">
	      			<img src="<?php echo e(asset('images/custom.jpg')); ?>" width="100%" style="margin-bottom: 20px;">
	      			<h2 style="border-bottom: solid 1px #000000">Application Scheme</h2>
	      			
	           	</div>
	      		<div class="tab-pane fade" id="v-pills-profession" role="tabpanel" aria-labelledby="v-pills-profession-tab">
	      			<img src="<?php echo e(asset('images/custom.jpg')); ?>" width="100%" style="margin-bottom: 20px;">
	      			<h2 style="border-bottom: solid 1px #000000">Products Catalog</h2>
	      			<ul compact="list-unstyled">
	      				<?php $__currentLoopData = $catalogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $catalog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	      				<li><a href="<?php echo e(route('download', [$catalog->id])); ?>" style="color: #000000；"><span class="glyphicon glyphicon-download-alt"></span>Click to download <strong><?php echo e($catalog->getProductName($catalog->product_id)['name']); ?>'s E-catalog: <?php echo e($catalog->file); ?></strong></a></li>
	      				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	      			</ul>
	      			<?php echo e($catalogs->links()); ?>

	           	</div>
	           	<div class="tab-pane fade" id="v-pills-service" role="tabpanel" aria-labelledby="v-pills-service-tab">
	      			<img src="<?php echo e(asset('images/custom.jpg')); ?>" width="100%" style="margin-bottom: 20px;">
	      			<h2 style="border-bottom: solid 1px #000000">Product coding principle</h2>
	      			
	           	</div>
	    	</div>
	  	</div>
	</div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('css/details.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\FreelancerTasks\local.linkbasic.com\resources\views/pages/custom.blade.php ENDPATH**/ ?>