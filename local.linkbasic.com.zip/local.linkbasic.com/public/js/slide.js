var page = {
    delete_id: null,
    init: function() {
        this.bindEvent();
        this.render();    
    },

    bindEvent: function() {
    	$('#slide_image').on('change', function() {

    	})



    },

    render: function() {

    }
}

$(document).ready(function() {    
	

})

