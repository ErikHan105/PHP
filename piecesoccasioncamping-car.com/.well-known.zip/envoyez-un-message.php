<?php

include "main.php";

$md5 = AntiInjectionSQL($_REQUEST['md5']);

$error = NULL;
$msg_valid = NULL;

$SQL = "SELECT COUNT(*) FROM pas_annonce WHERE md5 = '$md5'";
$reponse = $pdo->query($SQL);
$req = $reponse->fetch();

if($req[0] == 0)
{
	header("Location: 404.php");
	exit;
}

if(isset($_REQUEST['action']))
{
	$action = $_REQUEST['action'];
	if($action == 1)
	{
		$md5 = AntiInjectionSQL($_REQUEST['md5']);
		$nom = AntiInjectionSQL($_REQUEST['nom']);
		$email = AntiInjectionSQL($_REQUEST['email']);
		$msg = AntiInjectionSQL($_REQUEST['message']);
		$error = -1;
		
		if($nom == '')
		{
			$error = 1;
		}
		if($email == '')
		{
			$error = 1;
		}
		if($msg == '')
		{
			$error = 1;
		}
		
		if($error == 1)
		{
			//
		}
		else
		{
		
			// On recupere l'email de l'utilisateur de l'annonce
			$SQL = "SELECT * FROM pas_annonce WHERE md5 = '$md5'";
			$reponse = $pdo->query($SQL);
			$req = $reponse->fetch();
			
			$iduser = $req['iduser'];
			$titre = $req['titre'];
			
			$SQL = "SELECT * FROM pas_user WHERE id = $iduser";
			$reponse = $pdo->query($SQL);
			$req = $reponse->fetch();
			
			$emailuser = $req['email'];
			
			/* Envoie du mail */
			$sujet = getConfig("sujet_mail_reponse_annonce");
			$messageHTML = getConfig("email_reponse_annonce_html");
			$messageTEXTE = getConfig("email_reponse_annonce_text");
			
			$expediteurmail = getConfig("nom_expediteur_mail");
			$adresse_expediteur_mail = getConfig("adresse_expediteur_mail");
			$reply_expediteur_mail = getConfig("reply_expediteur_mail");
			
			$sujet = str_replace("[titre]",$titre,$sujet);
			$sujet = str_replace("[nom]",$nom,$sujet);
			$sujet = str_replace("[email]",$email,$sujet);
			$sujet = utf8_decode($sujet);
			
			$messageHTML = str_replace("[titre]",$titre,$messageHTML);
			$messageHTML = str_replace("[email]",$email,$messageHTML);
			$messageHTML = str_replace("[nom]",$nom,$messageHTML);
			$messageHTML = str_replace("[message]",$msg,$messageHTML);
			$messageHTML = str_replace("[saut_ligne]","<br>",$messageHTML);
			$messageHTML = str_replace("[logo]",'<img src="'.$url_script.'/images/'.getConfig("logo").'">',$messageHTML);	
			$messageHTML = '<html><body>'.$messageHTML.'</body></html>';
			
			$messageTEXTE = str_replace("[titre]",$titre,$messageTEXTE);
			$messageTEXTE = str_replace("[email]",$email,$messageTEXTE);
			$messageTEXTE = str_replace("[nom]",$nom,$messageTEXTE);
			$messageTEXTE = str_replace("[message]",$msg,$messageTEXTE);
			$messageTEXTE = str_replace("[saut_ligne]","",$messageTEXTE);
			$messageTEXTE = str_replace("[logo]","",$messageTEXTE);
			
			$boundary = "-----=".md5(rand());
			$passage_ligne = "\r\n";
			
			$header = "From: \"$expediteurmail\"<$adresse_expediteur_mail>".$passage_ligne;
			$header.= "Reply-to: \"$nom\" <$emailuser>".$passage_ligne;
			$header.= "MIME-Version: 1.0".$passage_ligne;
			$header.= "Content-Type: multipart/alternative;".$passage_ligne." boundary=\"$boundary\"".$passage_ligne;
			
			//=====Création du message.
			$message = $passage_ligne."--".$boundary.$passage_ligne;
			//=====Ajout du message au format texte.
			$message.= "Content-Type: text/plain; charset=\"ISO-8859-1\"".$passage_ligne;
			$message.= "Content-Transfer-Encoding: 8bit".$passage_ligne;
			$message.= $passage_ligne.$messageTEXTE.$passage_ligne;
			//==========
			$message.= $passage_ligne."--".$boundary.$passage_ligne;
			//=====Ajout du message au format HTML
			$message.= "Content-Type: text/html; charset=\"UTF-8\"".$passage_ligne;
			$message.= "Content-Transfer-Encoding: 8bit".$passage_ligne;
			$message.= $passage_ligne.$messageHTML.$passage_ligne;
			//==========
			$message.= $passage_ligne."--".$boundary."--".$passage_ligne;
			$message.= $passage_ligne."--".$boundary."--".$passage_ligne;
			mail($emailuser,$sujet,$message,$header);
			
			header("Location: envoyez-un-message.php?md5=".$md5."&valid=1");
			exit;
		}
	}
}

$SQL = "SELECT * FROM pas_annonce WHERE md5 = '$md5'";
$reponse = $pdo->query($SQL);
$req = $reponse->fetch();

$titre = $req['titre'];
$date_soumission = $req['date_soumission'];
$prix = $req['prix'];
$codepostal = $req['codepostal'];
$description = $req['texte'];
$idcategorie = $req['idcategorie'];
$iduser = $req['iduser'];
$nbr_vue = $req['nbr_vue'];
$telephone = $req['telephone'];

// On recupere le nom de la categorie
$SQL = "SELECT * FROM pas_categorie WHERE id = $idcategorie";
$reponse = $pdo->query($SQL);
$req = $reponse->fetch();

$namecategorie = $req['titre'];

// Recupere le pseudo de l'utilisateur
$SQL = "SELECT * FROM pas_user WHERE id = $iduser";
$reponse = $pdo->query($SQL);
$req = $reponse->fetch();

$username = $req['username'];	

// On recupere les images
$arrayImage = NULL;
$SQL = "SELECT * FROM pas_image WHERE md5annonce = '$md5'";
$reponse = $pdo->query($SQL);
while($req = $reponse->fetch())
{
	$arrayImage[count($arrayImage)] = $req['image'];
}

if(count($arrayImage) == 0)
{
	$bigimg = 'noimage.jpg';
}
else
{
	$bigimg = "annonce/".$arrayImage[0];
}

$template = getConfig("template");

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Envoyez un message à l'annonce <?php echo $titre; ?> - PAS Script</title>
	<meta name="description" content="<?php echo strip_tags(str_replace(CHR(13).CHR(10),"",$description)); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<link rel="stylesheet" type="text/css" href="<?php echo $url_script; ?>/template/<?php echo $template; ?>/css/main.css">
	<link rel="stylesheet" type="text/css" href="<?php echo $url_script; ?>/template/<?php echo $template; ?>/css/responsive.css">
	<link href="css/jqvmap.css" media="screen" rel="stylesheet" type="text/css" />
	<link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js" type="text/javascript"></script>
	<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
	<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
</head>
<?php

$class_templateloader->openBody();
include "header.php";

$class_templateloader->loadTemplate("tpl/message.tpl");
$class_templateloader->assign("{md5}",$md5);
$class_templateloader->assign("{username}",$username);

if($error == 1)
{
	$msg_valid = '<div class="errormsg">';
	$msg_valid .= 'Merci de remplir tous les champs.';
	$msg_valid .= '</div>';
}

if(isset($_REQUEST['valid']))
{
	$msg_valid = '<div class="validmsg">';
	$msg_valid .= 'Votre message a été envoyé avec succès';
	$msg_valid .= '</div>';
}

$class_templateloader->assign("{msg_valid}",$msg_valid);	
$class_templateloader->show();

include "footer.php";

$class_templateloader->closeBody();
$class_templateloader->closeHTML();
	
?>