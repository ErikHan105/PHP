<?php $__env->startSection('content'); ?>

<div class="back-image">
	<img src="<?php echo e(asset('images/bg_company.jpg')); ?>" width="100%">
</div>
<div class="container">
	<div class="row content">
		<div class="col-3">
			<div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">

				<a class="nav-link disabled" id="v-pills-product-tab" data-toggle="pill" href="#v-pills-product" role="tab" aria-controls="v-pills-product" aria-selected="false">
					<h5>Contact Us</h5>
				</a>

		   	</div>
		   	<div class="row menu-picture">
				<a href="<?php echo e(route('custom')); ?>" class="side-menu"><img src="<?php echo e(asset('images/pdf_download.jpg')); ?>" width="100%"></a>
			</div>
			<div class="row menu-picture">
				<a href="<?php echo e(route('products')); ?>" class="side-menu"><img src="<?php echo e(asset('images/products_.jpg')); ?>" width="100%"></a>
			</div>

		</div>
		<div class="col-8">
			<div class="tab-content" id="v-pills-tabContent">	      		
	      		<div class="" id="v-pills-who" role="tabpanel" aria-labelledby="v-pills-who-tab">
	      			<img src="<?php echo e(asset('images/contact.jpg')); ?>" width="100%" style="margin-bottom: 20px;">
	      			<h2>Contact us</h2>
	      			<p><?php echo $companyinfo->name; ?></p>

					<p>Address: <?php echo $companyinfo->address; ?></p>

					<p>Zip code： <?php echo $companyinfo->zipcode; ?></p><br/>
					<h2>Products sales information</h2>
					<h4>America, East Europe</h4>
	      			<p>TEL:<?php echo $companyinfo->tel_america; ?></p>
            		<p>E-mail：<?php echo $companyinfo->email_america; ?></p><br/>
            		<h4>Asia, Africa, Oceania, West Europe</h4>
            		<p>TEL:<?php echo $companyinfo->tel_asia; ?></p>
            		<p>E-mail：<?php echo $companyinfo->email_asia; ?></p>
            		<h2>Invoice & Remittance</h2>
            		<p>Bank : <?php echo $companyinfo->bank; ?><br/>
						Bank Address : <?php echo $companyinfo->bank_address; ?><br/>
						Beneficiary : <?php echo $companyinfo->beneficiary; ?><br/>
						BeneficiaryAddress : ROOM674, NO.16, ZHONGCHUANGYUAN,  BINHAISI ROAD NORTH,   HANGZHOU BAY NEW ZONE,  NINGBO,  ZHEJIANG PROVINCE<br/>
						SWIFT Code : <?php echo $companyinfo->swiftcode; ?><br/>
						Account Number : <?php echo $companyinfo->account; ?>

					</p>
	           	</div>

	    	</div>
	  	</div>
	</div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('css/details.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\FreelancerTasks\local.linkbasic.com\resources\views/pages/contact.blade.php ENDPATH**/ ?>